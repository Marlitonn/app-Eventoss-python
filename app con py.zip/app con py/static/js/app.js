// ==================== IMÁGENES ====================
const images = {
    salsa: 'https://images.unsplash.com/photo-1547153760-18fc86324498?w=600',
    bachata: 'https://images.unsplash.com/photo-1504609773096-104ff2c73ba4?w=600',
    quince: 'https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8?w=600',
    boda: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=600',
    dj: 'https://images.unsplash.com/photo-1571266028243-37160d7fdd04?w=600',
    venue: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=600',
    decor: 'https://images.unsplash.com/photo-1530103862676-de3c9a59af57?w=600',
    catering: 'https://images.unsplash.com/photo-1555244162-803834f70033?w=600',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200'
};

// ==================== LISTA DOBLEMENTE ENLAZADA ====================
class Nodo {
    constructor(data) {
        this.data = data;
        this.siguiente = null;
        this.anterior = null;
    }
}

class ListaDoble {
    constructor() {
        this.cabeza = null;
        this.cola = null;
        this.tamaño = 0;
    }
    
    agregar(data) {
        const nuevo = new Nodo(data);
        if (!this.cabeza) {
            this.cabeza = this.cola = nuevo;
        } else {
            this.cola.siguiente = nuevo;
            nuevo.anterior = this.cola;
            this.cola = nuevo;
        }
        this.tamaño++;
    }

    agregarInicio(data) {
        const nuevo = new Nodo(data);
        if (!this.cabeza) {
            this.cabeza = this.cola = nuevo;
        } else {
            nuevo.siguiente = this.cabeza;
            this.cabeza.anterior = nuevo;
            this.cabeza = nuevo;
        }
        this.tamaño++;
    }

    recorrer() {
        let actual = this.cabeza;
        const datos = [];
        while (actual) {
            datos.push(actual.data);
            actual = actual.siguiente;
        }
        return datos;
    }

    recorrerReversa() {
        let actual = this.cola;
        const datos = [];
        while (actual) {
            datos.push(actual.data);
            actual = actual.anterior;
        }
        return datos;
    }

    buscar(id) {
        let actual = this.cabeza;
        while (actual) {
            if (actual.data.id === id) return actual.data;
            actual = actual.siguiente;
        }
        return null;
    }

    buscarPorNombre(nombre) {
        let actual = this.cabeza;
        while (actual) {
            if (actual.data.name.toLowerCase().includes(nombre.toLowerCase())) return actual.data;
            actual = actual.siguiente;
        }
        return null;
    }

    contar() {
        return this.tamaño;
    }

    actualizar(id, newData) {
        let actual = this.cabeza;
        while (actual) {
            if (actual.data.id === id) {
                actual.data = { ...actual.data, ...newData };
                return true;
            }
            actual = actual.siguiente;
        }
        return false;
    }

    ordenarPorScore() {
        const datos = this.recorrer();
        return datos.sort((a, b) => b.score - a.score);
    }
}

// ==================== INSTANCIA DE LISTA ====================
let lista = new ListaDoble();

// ==================== FILTROS ====================
let currentCategoryFilter = 'todos';
let currentPriceFilter = 'all';
let customPriceRange = { min: null, max: null };

// ==================== USUARIO ====================
let currentUser = null;
let userStories = [];
let userPosts = [];
let userLiked = [];
let userReservations = [];
let userFollowing = []; // Usuarios que sigo
let userFollowers = []; // Usuarios que me siguen
let isOrganizer = false;
let totalLikes = 0;
let totalReservations = 0;
let activeUsers = Math.floor(Math.random() * 50) + 10;

// ==================== COMENTARIOS ====================
let itemComments = {}; // { itemId: [{ user, text, date }] }

// ==================== AUTH LOCAL ====================
function getUsers() {
    return JSON.parse(localStorage.getItem('evenbu_users')) || [];
}


function getCurrentSession() {
    return JSON.parse(localStorage.getItem('evenbu_session')) || null;
}

function saveSession(user) {
    localStorage.setItem('evenbu_session', JSON.stringify(user));
}

function clearSession() {
    localStorage.removeItem('evenbu_session');
}

// ==================== GUARDAR Y CARGAR DATOS DE USUARIO ====================
function saveUserLists() {
    if (!currentUser) return;
    localStorage.setItem(`reservations_${currentUser.id}`, JSON.stringify(userReservations));
    localStorage.setItem(`liked_${currentUser.id}`, JSON.stringify(userLiked));
    localStorage.setItem(`following_${currentUser.id}`, JSON.stringify(userFollowing));
    localStorage.setItem(`followers_${currentUser.id}`, JSON.stringify(userFollowers));
    localStorage.setItem(`posts_${currentUser.id}`, JSON.stringify(userPosts));
    localStorage.setItem(`stories_${currentUser.id}`, JSON.stringify(userStories));
}

function loadUserData() {
    if (!currentUser) return;
    userReservations = JSON.parse(localStorage.getItem(`reservations_${currentUser.id}`)) || [];
    userLiked = JSON.parse(localStorage.getItem(`liked_${currentUser.id}`)) || [];
    userFollowing = JSON.parse(localStorage.getItem(`following_${currentUser.id}`)) || [];
    userFollowers = JSON.parse(localStorage.getItem(`followers_${currentUser.id}`)) || [];
    userPosts = JSON.parse(localStorage.getItem(`posts_${currentUser.id}`)) || [];
    userStories = JSON.parse(localStorage.getItem(`stories_${currentUser.id}`)) || [];
}




function checkAuthAndCreate() {
    if (!currentUser) {
        showNotification('Debes iniciar sesión', 'error');
        openModal('loginModal');
        return;
    }
    if (!isOrganizer) {
        showNotification('Activa modo organizador en ajustes', 'error');
        openModal('settingsModal');
        return;
    }
    openModal('createModal');
}

function handleReserve(e) {
    e.preventDefault();
    const itemName = document.getElementById('reserveItem').value;
    const item = lista.buscarPorNombre(itemName);
    if (!item) return;
    
    userReservations.push({
        id: Date.now(),
        itemName: item.name,
        itemImage: item.image,
        itemPrice: item.price,
        date: document.getElementById('reserveDate').value,
        guests: document.getElementById('reserveGuests').value,
        type: document.getElementById('reserveType').value,
        status: 'pay-later',
        organizer: item.organizer
    });

    item.reservations++;
    totalReservations++;
    lista.actualizar(item.id, { reservations: item.reservations });

    if (currentUser) currentUser.reservations = userReservations.length;
  
    saveUserLists();
    
    closeModal('reserveModal');
    renderFeed();
    updateProfile();
    updateStats();
    showNotification('¡Reserva confirmada! Paga el día del evento 💳', 'success');
}

function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    const users = getUsers();
    const user = users.find(u => u.email === email && u.password === password);

    if (!user) {
        showNotification('Email o contraseña incorrectos', 'error');
        return;
    }

    currentUser = { ...user };
    delete currentUser.password;
    isOrganizer = currentUser.isOrganizer || false;
    saveSession(currentUser);
    
  
    loadUserData();

    updateUserInfo();
    updateProfile();
    closeModal('loginModal');
    showNotification('¡Bienvenido! ' + currentUser.name, 'success');
}

function handleSocialLogin(provider) {
    showNotification('Solo registro local disponible', 'error');
}

function logout() {
    currentUser = null;
    isOrganizer = false;
    userReservations = [];
    userLiked = [];
    userFollowing = [];
    userFollowers = [];
    userPosts = [];
    userStories = [];
    clearSession();
    updateLoggedOutUI();
    showNotification('Sesión cerrada', 'success');
}

function updateLoggedOutUI() {
    document.getElementById('userInfo').style.display = 'none';
    document.getElementById('btnLogin').style.display = 'block';
    document.getElementById('btnRegister').style.display = 'block';
    document.getElementById('btnLogout').style.display = 'none';
    document.getElementById('btnOrganizer').style.display = 'none';
}

function updateUserInfo() {
    if (currentUser) {
        document.getElementById('userInfo').style.display = 'flex';
        document.getElementById('userName').textContent = currentUser.name;
        document.getElementById('headerUserAvatar').src = currentUser.avatar;
        document.getElementById('btnLogin').style.display = 'none';
        document.getElementById('btnRegister').style.display = 'none';
        document.getElementById('btnLogout').style.display = 'block';
        document.getElementById('btnOrganizer').style.display = 'block';
        document.getElementById('organizerBadge').style.display = isOrganizer ? 'inline-block' : 'none';
    }
}

function updateProfile() {
    if (!currentUser) return;
    document.getElementById('profileAvatar').src = currentUser.avatar;
    document.getElementById('profileName').textContent = currentUser.name;
    document.getElementById('profileUsername').textContent = '@' + currentUser.username;
    document.getElementById('profileBio').textContent = currentUser.bio;
    document.getElementById('profilePosts').textContent = userPosts.length;
    document.getElementById('profileFollowers').textContent = userFollowers.length;
    document.getElementById('profileFollowing').textContent = userFollowing.length;
    document.getElementById('profileReservations').textContent = userReservations.length;
    document.getElementById('settingsAvatar').src = currentUser.avatar;
    document.getElementById('settingsName').value = currentUser.name;
    document.getElementById('settingsUsername').value = currentUser.username;
    document.getElementById('settingsBio').value = currentUser.bio;
    renderUserContent('posts');
    renderStories();
    updateStats();
}

function handleSettings(e) {
    e.preventDefault();
    currentUser.name = document.getElementById('settingsName').value;
    currentUser.username = document.getElementById('settingsUsername').value.replace('@', '');
    currentUser.bio = document.getElementById('settingsBio').value;
    const users = getUsers();
    const index = users.findIndex(u => u.email === currentUser.email);
    if (index >= 0) {
        users[index] = { ...users[index], ...currentUser };
        localStorage.setItem('evenbu_users', JSON.stringify(users));
    }
    saveSession(currentUser);
    updateUserInfo();
    updateProfile();
    closeModal('settingsModal');
    showNotification('¡Perfil actualizado!', 'success');
}

function toggleOrganizerMode() {
    if (!currentUser) {
        showNotification('Inicia sesión primero', 'error');
        openModal('loginModal');
        return;
    }
    isOrganizer = !isOrganizer;
    currentUser.isOrganizer = isOrganizer;
    saveSession(currentUser);
    const users = getUsers();
    const index = users.findIndex(u => u.email === currentUser.email);
    if (index >= 0) {
        users[index].isOrganizer = isOrganizer;
        localStorage.setItem('evenbu_users', JSON.stringify(users));
    }
    document.getElementById('organizerBadge').style.display = isOrganizer ? 'inline-block' : 'none';
    document.getElementById('organizerToggle').classList.toggle('active', isOrganizer);
    showNotification(isOrganizer ? 'Modo organizador activado 🎤' : 'Modo organizador desactivado', 'success');
}

function previewAvatar(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = (e) => {
            currentUser.avatar = e.target.result;
            document.getElementById('settingsAvatar').src = e.target.result;
            document.getElementById('profileAvatar').src = e.target.result;
            document.getElementById('headerUserAvatar').src = e.target.result;
            saveSession(currentUser);
        };
        reader.readAsDataURL(input.files[0]);
        showNotification('Foto actualizada', 'success');
    }
}

function toggleSwitch(el) {
    el.classList.toggle('active');
}

// ==================== SEGUIR USUARIOS ====================
function followUser(userId, userName, userAvatar) {
    if (!currentUser) {
        showNotification('Inicia sesión para seguir', 'error');
        openModal('loginModal');
        return;
    }
    
    const index = userFollowing.findIndex(u => u.id === userId);
    if (index === -1) {
        userFollowing.push({ id: userId, name: userName, avatar: userAvatar });
        userFollowers.push({ id: currentUser.id, name: currentUser.name, avatar: currentUser.avatar });
        saveUserLists();
        saveUserData();
        showNotification('Siguiendo a ' + userName, 'success');
    } else {
        userFollowing.splice(index, 1);
        saveUserLists();
        saveUserData();
        showNotification('Dejaste de seguir', 'success');
    }
    updateProfile();
}

function getOrganizerFromItem(item) {
    const users = getUsers();
    return users.find(u => u.name === item.organizer) || { id: item.organizer, name: item.organizer, avatar: images.avatar };
}

// ==================== COMENTARIOS ====================
function addComment(itemId, text) {
    if (!currentUser) {
        showNotification('Inicia sesión para comentar', 'error');
        openModal('loginModal');
        return;
    }
    if (!text.trim()) return;
    
    if (!itemComments[itemId]) itemComments[itemId] = [];
    itemComments[itemId].push({
        user: currentUser.name,
        avatar: currentUser.avatar,
        text: text,
        date: new Date().toLocaleDateString()
    });
    
    const item = lista.buscar(itemId);
    if (item) {
        item.comments = (item.comments || 0) + 1;
        lista.actualizar(itemId, { comments: item.comments });
    }
    
    saveUserLists();
    renderFeed();
    showNotification('Comentario añadido', 'success');
}

function getComments(itemId) {
    return itemComments[itemId] || [];
}

function openCommentsModal(itemId) {
    const item = lista.buscar(itemId);
    if (!item) return;
    
    document.getElementById('commentItemName').textContent = item.name;
    document.getElementById('commentCount').textContent = (item.comments || 0);
    
    const commentsList = document.getElementById('commentsList');
    const comments = getComments(itemId);
    
    if (comments.length === 0) {
        commentsList.innerHTML = '<p style="color: #666; text-align: center; padding: 20px;">Sé el primero en comentar</p>';
    } else {
        commentsList.innerHTML = comments.map(c => `
            <div style="display: flex; gap: 10px; padding: 10px; border-bottom: 1px solid #333;">
                <img src="${c.avatar}" style="width: 32px; height: 32px; border-radius: 50%;">
                <div>
                    <div style="font-weight: bold; font-size: 13px;">${c.user}</div>
                    <div style="color: #ccc; font-size: 13px;">${c.text}</div>
                    <div style="color: #666; font-size: 11px;">${c.date}</div>
                </div>
            </div>
        `).join('');
    }
    
    openModal('commentsModal');
}

function handleAddComment(e) {
    e.preventDefault();
    const text = document.getElementById('commentInput').value;
    const itemName = document.getElementById('commentItemName').textContent;
    const item = lista.buscarPorNombre(itemName);
    if (item) {
        addComment(item.id, text);
        document.getElementById('commentInput').value = '';
        openCommentsModal(item.id);
    }
}

// ==================== FILTROS DE PRECIOS ====================
function togglePriceFilter() {
    document.getElementById('priceFilterDropdown').classList.toggle('show');
}

function selectPriceRange(range, element) {
    document.querySelectorAll('.price-option').forEach(opt => opt.classList.remove('selected'));
    element.classList.add('selected');
    currentPriceFilter = range;
    customPriceRange = { min: null, max: null };
    const rangeTexts = {
        'all': 'Todos',
        '0-100': '$0-$100',
        '100-300': '$100-$300',
        '300-500': '$300-$500',
        '500+': '$500+'
    };
    document.getElementById('priceFilterCount').textContent = rangeTexts[range];
    document.getElementById('priceFilterDropdown').classList.remove('show');
    applyFilters();
    showNotification(`Filtro: ${rangeTexts[range]}`, 'success');
}

function applyCustomPriceRange() {
    const min = document.getElementById('minPrice').value;
    const max = document.getElementById('maxPrice').value;
    if (min || max) {
        customPriceRange = { min: min ? parseInt(min) : null, max: max ? parseInt(max) : null };
        currentPriceFilter = 'custom';
        document.getElementById('priceFilterCount').textContent = `$${min || 0}-$${max || '∞'}`;
        document.querySelectorAll('.price-option').forEach(opt => opt.classList.remove('selected'));
        document.getElementById('priceFilterDropdown').classList.remove('show');
        applyFilters();
        showNotification(`Rango: $${min || 0}-$${max || '∞'}`, 'success');
    } else {
        showNotification('Ingresa al menos un valor', 'error');
    }
}

function clearPriceFilter() {
    currentPriceFilter = 'all';
    customPriceRange = { min: null, max: null };
    document.querySelectorAll('.price-option').forEach(opt => opt.classList.remove('selected'));
    document.querySelectorAll('.price-option')[0].classList.add('selected');
    document.getElementById('minPrice').value = '';
    document.getElementById('maxPrice').value = '';
    document.getElementById('priceFilterCount').textContent = '';
    document.getElementById('priceFilterDropdown').classList.remove('show');
    applyFilters();
    showNotification('Filtro limpiado', 'success');
}

function checkPriceFilter(item) {
    if (currentPriceFilter === 'all') return true;
    if (currentPriceFilter === 'custom') {
        if (customPriceRange.min && item.price < customPriceRange.min) return false;
        if (customPriceRange.max && item.price > customPriceRange.max) return false;
        return true;
    }
    if (currentPriceFilter === '500+') return item.price >= 500;
    const [min, max] = currentPriceFilter.split('-').map(v => parseInt(v));
    return item.price >= min && item.price <= max;
}

function updateActiveFiltersDisplay() {
    const container = document.getElementById('activeFilters');
    container.innerHTML = '';
    let hasFilters = false;
    
    if (currentCategoryFilter !== 'todos') {
        hasFilters = true;
        const categoryNames = {
            'salsa': '💃 Salsa',
            'bachata': '🎵 Bachata',
            'quinceaneras': '👑 15 Añeras',
            'bodas': '💍 Bodas',
            'corporativos': '💼 Corporativos'
        };
        const tag = document.createElement('div');
        tag.className = 'active-filter-tag';
        tag.innerHTML = `<span>${categoryNames[currentCategoryFilter]}</span><span class="remove-filter" onclick="clearCategoryFilter()">×</span>`;
        container.appendChild(tag);
    }

    if (currentPriceFilter !== 'all') {
        hasFilters = true;
        const tag = document.createElement('div');
        tag.className = 'active-filter-tag';
        tag.innerHTML = `<span>💰 ${document.getElementById('priceFilterCount').textContent}</span><span class="remove-filter" onclick="clearPriceFilter()">×</span>`;
        container.appendChild(tag);
    }

    container.style.display = hasFilters ? 'flex' : 'none';
}

function clearCategoryFilter() {
    currentCategoryFilter = 'todos';
    document.getElementById('categoryFilter').value = 'todos';
    applyFilters();
}

function applyFilters() {
    currentCategoryFilter = document.getElementById('categoryFilter').value;
    renderFeed();
    updateActiveFiltersDisplay();
}

// ==================== FEED TIKTOK STYLE ====================
let currentReelIndex = 0;

function renderFeed() {
    const container = document.getElementById('videosContainer');
    container.innerHTML = '';
    const datos = lista.recorrer();
    let filtered = datos.filter(item => {
        const categoryMatch = currentCategoryFilter === 'todos' || item.category === currentCategoryFilter;
        const priceMatch = checkPriceFilter(item);
        return categoryMatch && priceMatch;
    });

    const sorted = [...filtered].sort((a, b) => b.score - a.score);

    document.getElementById('resultsNumber').textContent = sorted.length;
    document.getElementById('resultsNumber').style.color = sorted.length > 0 ? '#fe2c55' : '#666';

    const categoryEmojis = {
        'salsa': '💃',
        'bachata': '🎵',
        'quinceaneras': '👑',
        'bodas': '💍',
        'corporativos': '💼'
    };

    if (sorted.length === 0) {
        container.innerHTML = `<div style="height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; color: #666;">
            <div style="font-size: 4em; margin-bottom: 20px;">🔍</div>
            <p>No se encontraron resultados</p>
            <button class="submit-btn" onclick="clearAllFilters()" style="margin-top: 20px; width: auto; padding: 10px 30px;">Limpiar Filtros</button>
        </div>`;
        return;
    }

    // TikTok style - Full screen reels
    sorted.forEach((item, index) => {
        const organizer = getOrganizerFromItem(item);
        const isLiked = userLiked.some(i => i.id === item.id);
        const isFollowing = userFollowing.some(u => u.id === organizer.id);
        
        const card = document.createElement('div');
        card.className = 'reel-card';
        card.innerHTML = `
            <div class="reel-content">
                <img src="${item.image}" class="reel-image" alt="${item.name}">
                <div class="reel-overlay">
                    <div class="reel-info">
                        <div class="reel-user" onclick="followUser('${organizer.id}', '${organizer.name}', '${organizer.avatar}')">
                            <img src="${organizer.avatar}" class="reel-avatar">
                            <div>
                                <div class="reel-username">@${organizer.name.toLowerCase().replace(' ', '')}</div>
                                <button class="follow-btn ${isFollowing ? 'following' : ''}">${isFollowing ? 'Siguiendo' : 'Seguir'}</button>
                            </div>
                        </div>
                        <h3 class="reel-title">${categoryEmojis[item.category] || '📌'} ${item.name}</h3>
                        <p class="reel-description">${item.description}</p>
                        <div class="reel-meta">
                            <span>💰 $${item.price}</span>
                            <span>⭐ ${item.score}/100</span>
                        </div>
                    </div>
                    <div class="reel-actions">
                        <button class="reel-action-btn" onclick="likeItem(${item.id}, this)">
                            <div class="reel-action-icon ${isLiked ? 'liked' : ''}">❤️</div>
                            <span class="reel-action-count">${item.likes}</span>
                        </button>
                        <button class="reel-action-btn" onclick="openCommentsModal(${item.id})">
                            <div class="reel-action-icon">💬</div>
                            <span class="reel-action-count">${item.comments || 0}</span>
                        </button>
                        <button class="reel-action-btn" onclick="openReserveModal('${item.name}', ${item.price})">
                            <div class="reel-action-icon" style="background:#25f4ee;color:#000;border-radius:50%;">📅</div>
                            <span class="reel-action-count">${item.reservations}</span>
                        </button>
                        <button class="reel-action-btn" onclick="showNotification('Compartido', 'success')">
                            <div class="reel-action-icon">🔗</div>
                            <span class="reel-action-count">${item.shares || 0}</span>
                        </button>
                    </div>
                </div>
            </div>
        `;
        container.appendChild(card);
    });

    // Enable scroll snap
    container.style.scrollSnapType = 'y mandatory';
    updateStats();
}

function clearAllFilters() {
    currentCategoryFilter = 'todos';
    document.getElementById('categoryFilter').value = 'todos';
    clearPriceFilter();
    showNotification('Filtros limpiados', 'success');
}

function likeItem(id, btn) {
    if (!currentUser) {
        showNotification('Inicia sesión para dar like', 'error');
        openModal('loginModal');
        return;
    }
    
    const item = lista.buscar(id);
    if (!item) return;
    
    const index = userLiked.findIndex(i => i.id === id);
    if (index === -1) {
        item.likes++;
        userLiked.push(item);
        btn.querySelector('.reel-action-icon').classList.add('liked');
        lista.actualizar(id, { likes: item.likes });
    } else {
        item.likes--;
        userLiked.splice(index, 1);
        btn.querySelector('.reel-action-icon').classList.remove('liked');
        lista.actualizar(id, { likes: item.likes });
    }

    saveUserLists();
    totalLikes = userLiked.length;
    updateStats();
    renderFeed();
}

function openReserveModal(itemName, itemPrice) {
    if (!currentUser) {
        showNotification('Inicia sesión para reservar', 'error');
        openModal('loginModal');
        return;
    }
    document.getElementById('reserveItem').value = itemName;
    document.getElementById('reservePrice').value = `$${itemPrice}`;
    openModal('reserveModal');
}

function handleReserve(e) {
    e.preventDefault();
    const itemName = document.getElementById('reserveItem').value;
    const item = lista.buscarPorNombre(itemName);
    if (!item) return;
    
    userReservations.push({
        id: Date.now(),
        itemId: item.id,
        itemName: item.name,
        itemImage: item.image,
        itemPrice: item.price,
        date: document.getElementById('reserveDate').value,
        guests: document.getElementById('reserveGuests').value,
        type: document.getElementById('reserveType').value,
        status: 'pay-later',
        organizer: item.organizer,
        createdAt: new Date().toISOString()
    });

    item.reservations++;
    totalReservations++;
    lista.actualizar(item.id, { reservations: item.reservations });

    if (currentUser) currentUser.reservations = userReservations.length;
    
   
    saveUserLists();
    
    closeModal('reserveModal');
    renderFeed();
    updateProfile();
    updateStats();
    showNotification('¡Reserva confirmada! Paga el día del evento 💳', 'success');
}

function cancelReservation(reservationId) {
    const reservation = userReservations.find(r => r.id === reservationId);
    if (reservation) {
        reservation.status = 'cancelled';

        saveUserLists();
        renderUserContent('reservations');
        updateProfile();
        showNotification('Reserva cancelada', 'success');
    }
}

function payReservation(reservationId) {
    const reservation = userReservations.find(r => r.id === reservationId);
    if (reservation) {
        reservation.status = 'confirmed';
        saveUserLists();
        renderUserContent('reservations');
        updateProfile();
        showNotification('¡Pago confirmado!', 'success');
    }
}

// ==================== VISTAS ====================
function switchView(view) {
    document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
    event.target.classList.add('active');
    
    if (view === 'feed') {
        document.getElementById('mainContent').style.display = 'grid';
        document.getElementById('feedView').style.display = 'block';
        document.getElementById('organizersView').style.display = 'none';
        document.getElementById('sidebar').style.display = 'flex';
        document.getElementById('profileView').style.display = 'none';
        renderFeed();
    } else if (view === 'organizers') {
        document.getElementById('mainContent').style.display = 'block';
        document.getElementById('feedView').style.display = 'none';
        document.getElementById('organizersView').style.display = 'block';
        document.getElementById('sidebar').style.display = 'none';
        document.getElementById('profileView').style.display = 'none';
        renderOrganizers();
    } else if (view === 'profile') {
        if (!currentUser) {
            showNotification('Inicia sesión', 'error');
            openModal('loginModal');
            return;
        }
        document.getElementById('mainContent').style.display = 'block';
        document.getElementById('feedView').style.display = 'none';
        document.getElementById('organizersView').style.display = 'none';
        document.getElementById('sidebar').style.display = 'none';
        document.getElementById('profileView').style.display = 'block';
        updateProfile();
    } else if (view === 'top10') {
        document.getElementById('mainContent').style.display = 'block';
        document.getElementById('feedView').style.display = 'none';
        document.getElementById('organizersView').style.display = 'none';
        document.getElementById('sidebar').style.display = 'none';
        document.getElementById('profileView').style.display = 'none';
        renderTop10();
    } else if (view === 'products') {
        document.getElementById('mainContent').style.display = 'block';
        document.getElementById('feedView').style.display = 'none';
        document.getElementById('organizersView').style.display = 'none';
        document.getElementById('sidebar').style.display = 'none';
        document.getElementById('profileView').style.display = 'none';
        renderProducts();
    }
}

function renderOrganizers() {
    const container = document.getElementById('organizersContainer');
    container.innerHTML = '';
    const datos = lista.recorrerReversa();
    const organizers = {};
    
    datos.forEach(item => {
        if (!organizers[item.organizer]) organizers[item.organizer] = [];
        organizers[item.organizer].push(item);
    });

    Object.keys(organizers).forEach(orgName => {
        const orgDiv = document.createElement('div');
        orgDiv.style.padding = '20px';
        orgDiv.style.borderBottom = '1px solid #1a1a1a';
        orgDiv.innerHTML = `
            <h3 style="color: #fe2c55; margin-bottom: 15px;">🎤 ${orgName}</h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px;">
                ${organizers[orgName].map(item => `
                    <div style="background: #111; border-radius: 8px; overflow: hidden; border: 1px solid #333;">
                        <img src="${item.image}" style="width: 100%; height: 150px; object-fit: cover;">
                        <div style="padding: 15px;">
                            <h4 style="margin-bottom: 8px;">${item.name}</h4>
                            <p style="color: #888; font-size: 0.85em; margin-bottom: 10px;">${item.description}</p>
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <span style="color: #fe2c55; font-weight: 600;">$${item.price}</span>
                                <button class="submit-btn" style="width: auto; padding: 8px 15px; font-size: 0.85em;" onclick="openReserveModal('${item.name}', ${item.price})">Reservar</button>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
        container.appendChild(orgDiv);
    });
}

function renderTop10() {
    const sorted = lista.ordenarPorScore().slice(0, 10);
    const container = document.getElementById('videosContainer');
    container.innerHTML = '';
    
    sorted.forEach((item, i) => {
        const el = document.createElement('div');
        el.className = 'video-card';
        el.innerHTML = `
            <div style="padding: 20px; text-align: center;">
                <div style="font-size: 3em; color: ${i === 0 ? '#ffd700' : i === 1 ? '#c0c0c0' : i === 2 ? '#cd7f32' : '#666'};">#${i + 1}</div>
                <img src="${item.image}" style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; margin: 15px 0;">
                <h3>${item.name}</h3>
                <p style="color: #fe2c55; font-weight: bold;">$${item.price}</p>
                <p style="color: #888;">${item.description}</p>
                <button class="submit-btn" onclick="openReserveModal('${item.name}', ${item.price})">Reservar</button>
            </div>
        `;
        container.appendChild(el);
    });
}

function renderProducts() {
    const container = document.getElementById('videosContainer');
    container.innerHTML = '';
    const datos = lista.recorrer();
    const products = datos.filter(i => i.type === 'product');
    
    products.forEach(item => {
        const card = document.createElement('div');
        card.className = 'video-card';
        card.innerHTML = `
            <img src="${item.image}" class="video-content">
            <div class="video-overlay">
                <h3>🛒 ${item.name}</h3>
                <p>$${item.price}</p>
                <button class="submit-btn" onclick="openReserveModal('${item.name}', ${item.price})">Reservar</button>
            </div>
        `;
        container.appendChild(card);
    });
}

// ==================== USER CONTENT ====================
function switchContentTab(tab, el) {
    if (el) {
        document.querySelectorAll('.user-content-tab').forEach(t => t.classList.remove('active'));
        el.classList.add('active');
    }
    renderUserContent(tab);
}

function renderUserContent(tab = 'posts') {
    const container = document.getElementById('userContentGrid');
    if (!container) return;
    container.innerHTML = '';
    
    if (tab === 'reservations') {
        if (userReservations.length === 0) {
            container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 60px; color: #666;">📅<p>No tienes reservas</p></div>';
            return;
        }
        userReservations.forEach(res => {
            const el = document.createElement('div');
            el.className = 'reservation-card';
            el.style.gridColumn = '1 / -1';
            el.innerHTML = `
                <img src="${res.itemImage}" class="reservation-img">
                <div class="reservation-info">
                    <div class="reservation-name">${res.itemName}</div>
                    <span class="reservation-status ${res.status}">${res.status === 'pay-later' ? '💳 Paga Después' : res.status === 'confirmed' ? '✓ Confirmada' : '✕ Cancelada'}</span>
                    <div>📅 ${res.date} | 👥 ${res.guests} | 💰 $${res.itemPrice}</div>
                    <div style="font-size: 0.85em; color: #888; margin-top: 5px;">🎤 Organizador: ${res.organizer}</div>
                    ${res.status === 'pay-later' ? `<button class="reservation-btn cancel" onclick="cancelReservation(${res.id})">Cancelar</button><button class="reservation-btn pay" onclick="payReservation(${res.id})">Pagar Ahora</button>` : ''}
                </div>
            `;
            container.appendChild(el);
        });
        return;
    }
    
    if (tab === 'followers') {
        if (userFollowers.length === 0) {
            container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 60px; color: #666;">👥<p>No tienes seguidores aún</p></div>';
            return;
        }
        userFollowers.forEach(follower => {
            const el = document.createElement('div');
            el.className = 'follower-card';
            el.style.gridColumn = '1 / -1';
            el.innerHTML = `
                <div style="display: flex; align-items: center; gap: 15px; padding: 15px; background: #111; border-radius: 8px; margin-bottom: 10px;">
                    <img src="${follower.avatar}" style="width: 50px; height: 50px; border-radius: 50%;">
                    <div style="flex: 1;">
                        <div style="font-weight: bold;">${follower.name}</div>
                        <div style="color: #888; font-size: 13px;">@${follower.name.toLowerCase().replace(' ', '')}</div>
                    </div>
                </div>
            `;
            container.appendChild(el);
        });
        return;
    }
    
    if (tab === 'following') {
        if (userFollowing.length === 0) {
            container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 60px; color: #666;">👤<p>No sigues a nadie aún</p></div>';
            return;
        }
        userFollowing.forEach(following => {
            const el = document.createElement('div');
            el.className = 'follower-card';
            el.style.gridColumn = '1 / -1';
            el.innerHTML = `
                <div style="display: flex; align-items: center; gap: 15px; padding: 15px; background: #111; border-radius: 8px; margin-bottom: 10px;">
                    <img src="${following.avatar}" style="width: 50px; height: 50px; border-radius: 50%;">
                    <div style="flex: 1;">
                        <div style="font-weight: bold;">${following.name}</div>
                        <div style="color: #888; font-size: 13px;">@${following.name.toLowerCase().replace(' ', '')}</div>
                    </div>
                    <button class="profile-btn" onclick="followUser('${following.id}', '${following.name}', '${following.avatar}')">Dejar de seguir</button>
                </div>
            `;
            container.appendChild(el);
        });
        return;
    }

    let content = tab === 'posts'
        ? (userPosts.length > 0 ? userPosts : lista.recorrer().slice(0, 6))
        : userLiked.length > 0
            ? userLiked
            : lista.recorrer().slice(0, 6);

    content.forEach(item => {
        const el = document.createElement('div');
        el.className = 'user-content-item';
        el.innerHTML = `
            <img class="user-content-img" src="${item.image}">
            <div class="content-overlay">
                <div class="content-stat">❤️ ${item.likes}</div>
            </div>
        `;
        container.appendChild(el);
    });
}

// ==================== STORIES ====================
function renderStories() {
    const container = document.getElementById('storiesList');
    if (!container) return;
    container.innerHTML = '';
    
    const addBtn = document.createElement('div');
    addBtn.className = 'story-add';
    addBtn.innerHTML = '+';
    addBtn.onclick = () => openModal('addStoryModal');
    container.appendChild(addBtn);

    userStories.forEach((story, i) => {
        const el = document.createElement('div');
        el.className = 'story-item';
        el.innerHTML = `
            <div class="story-ring">
                <img class="story-img" src="${story.image}">
            </div>
            <div class="story-name">Estado ${i + 1}</div>
        `;
        container.appendChild(el);
    });
}

function handleAddStory(e) {
    e.preventDefault();
    userStories.push({ id: userStories.length + 1, image: images.avatar, createdAt: new Date() });
    saveUserLists();
    renderStories();
    closeModal('addStoryModal');
    showNotification('Estado publicado', 'success');
}

function handleCreate(e) {
    e.preventDefault();
    if (!currentUser) {
        showNotification('Inicia sesión', 'error');
        return;
    }
    if (!isOrganizer) {
        showNotification('Activa modo organizador', 'error');
        return;
    }
    const newItem = {
        id: lista.contar() + 1,
        name: document.getElementById('createTitle').value,
        description: document.getElementById('createDescription').value,
        type: document.getElementById('createType').value,
        category: document.getElementById('createCategory').value,
        price: parseInt(document.getElementById('createPrice').value),
        score: 50,
        likes: 0,
        comments: 0,
        shares: 0,
        reservations: 0,
        image: images.salsa,
        trending: false,
        organizer: currentUser.name
    };

    lista.agregarInicio(newItem);
    userPosts.push(newItem);

    if (currentUser) currentUser.posts = userPosts.length;
    
    saveUserLists();
    saveUserData();
    
    showNotification('¡Publicado!', 'success');
    closeModal('createModal');
    renderFeed();
    renderOrganizers();
    updateProfile();
    updateStats();
}

// ==================== UTILS ====================
function showNotification(msg, type = 'success') {
    const notif = document.getElementById('notification');
    document.getElementById('notificationText').textContent = msg;
    document.getElementById('notificationIcon').textContent = type === 'success' ? '✓' : '✕';
    notif.className = `notification show ${type}`;
    setTimeout(() => notif.classList.remove('show'), 3000);
}

function updateStats() {
    document.getElementById('totalLikes').textContent = totalLikes;
    document.getElementById('totalReservations').textContent = totalReservations;
    document.getElementById('activeUsers').textContent = activeUsers;
    document.getElementById('itemsCount').textContent = lista.contar();
}

function renderRanking() {
    const list = document.getElementById('rankingList');
    if (!list) return;
    list.innerHTML = '';
    const top = lista.ordenarPorScore().slice(0, 5);

    top.forEach((item, i) => {
        const el = document.createElement('div');
        el.className = 'ranking-item';
        let posClass = i === 0 ? 'gold' : i === 1 ? 'silver' : i === 2 ? 'bronze' : '';
        el.innerHTML = `
            <div class="ranking-pos ${posClass}">${i + 1}</div>
            <div class="ranking-info">
                <div class="ranking-name">${item.name}</div>
                <div class="ranking-score">${item.score}</div>
            </div>
        `;
        list.appendChild(el);
    });
}

function renderRecs() {
    const list = document.getElementById('recommendationsList');
    if (!list) return;
    list.innerHTML = '';
    const recs = lista.ordenarPorScore().slice(0, 3);

    recs.forEach(item => {
        const el = document.createElement('div');
        el.className = 'rec-item';
        el.innerHTML = `
            <img src="${item.image}" class="rec-img">
            <div class="rec-info">
                <div class="rec-name">${item.name}</div>
            </div>
        `;
        list.appendChild(el);
    });
}

// ==================== MODALES ====================
function openModal(id) {
    document.getElementById(id).classList.add('show');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('show');
}

function switchModal(from, to) {
    closeModal(from);
    openModal(to);
}

// ==================== DATOS INICIALES ====================
function inicializarDatos() {
    const datosIniciales = [
        { id: 1, name: 'Clases de Salsa', description: 'Aprende salsa con profesionales', type: 'service', category: 'salsa', price: 150, score: 98, likes: 450, comments: 89, shares: 120, reservations: 200, image: images.salsa, trending: true, organizer: 'Salsa Club' },
        { id: 2, name: 'DJ Bachata', description: 'Música para tu evento', type: 'service', category: 'bachata', price: 350, score: 95, likes: 380, comments: 72, shares: 95, reservations: 150, image: images.bachata, trending: true, organizer: 'Bachata Stars' },
        { id: 3, name: 'Salón 15 Añeros', description: 'Espacio elegante', type: 'service', category: 'quinceaneras', price: 1500, score: 94, likes: 520, comments: 105, shares: 180, reservations: 85, image: images.quince, trending: true, organizer: 'Eventos Premium' },
        { id: 4, name: 'Decoración Bodas', description: 'Decoración completa', type: 'product', category: 'bodas', price: 800, score: 92, likes: 340, comments: 68, shares: 90, reservations: 120, image: images.boda, trending: true, organizer: 'Decoraciones Elegantes' },
        { id: 5, name: 'Fotografía Eventos', description: 'Capturamos momentos', type: 'service', category: 'bodas', price: 600, score: 90, likes: 290, comments: 55, shares: 75, reservations: 110, image: images.boda, trending: false, organizer: 'FotoPro' },
        { id: 6, name: 'Iluminación LED', description: 'Efectos de luz', type: 'product', category: 'salsa', price: 250, score: 88, likes: 210, comments: 42, shares: 55, reservations: 80, image: images.dj, trending: false, organizer: 'LightShow' },
        { id: 7, name: 'Catering Fiestas', description: 'Comida deliciosa', type: 'service', category: 'quinceaneras', price: 500, score: 86, likes: 180, comments: 35, shares: 48, reservations: 65, image: images.catering, trending: false, organizer: 'Sabor Express' },
        { id: 8, name: 'Vestido 15 Añera', description: 'Vestidos exclusivos', type: 'product', category: 'quinceaneras', price: 1200, score: 85, likes: 420, comments: 95, shares: 150, reservations: 45, image: images.quince, trending: true, organizer: 'Moda Quince' },
        { id: 9, name: 'Show de Baile', description: 'Presentación profesional', type: 'service', category: 'salsa', price: 400, score: 83, likes: 165, comments: 32, shares: 42, reservations: 55, image: images.salsa, trending: false, organizer: 'Dance Show' },
        { id: 10, name: 'Sonido Profesional', description: 'Audio de calidad', type: 'product', category: 'corporativos', price: 350, score: 81, likes: 145, comments: 28, shares: 38, reservations: 50, image: images.dj, trending: false, organizer: 'Sound Pro' },
        { id: 11, name: 'Coreografía', description: 'Baile sorpresa', type: 'service', category: 'quinceaneras', price: 300, score: 79, likes: 125, comments: 25, shares: 32, reservations: 40, image: images.quince, trending: false, organizer: 'Coreo Dance' },
        { id: 12, name: 'Invitaciones', description: 'Invitaciones digitales', type: 'product', category: 'bodas', price: 100, score: 77, likes: 95, comments: 18, shares: 25, reservations: 35, image: images.boda, trending: false, organizer: 'Digital Invite' },
        { id: 13, name: 'Curso Bachata', description: 'Aprende desde cero', type: 'service', category: 'bachata', price: 80, score: 75, likes: 85, comments: 15, shares: 20, reservations: 30, image: images.bachata, trending: false, organizer: 'Bachata Academy' },
        { id: 14, name: 'Pastel Bodas', description: 'Pasteles personalizados', type: 'product', category: 'bodas', price: 250, score: 73, likes: 75, comments: 12, shares: 18, reservations: 25, image: images.catering, trending: false, organizer: 'Sweet Cakes' },
        { id: 15, name: 'Animación', description: 'Animadores profesionales', type: 'service', category: 'quinceaneras', price: 450, score: 71, likes: 65, comments: 10, shares: 15, reservations: 20, image: images.venue, trending: false, organizer: 'Party Animators' }
    ];
    datosIniciales.forEach(item => lista.agregar(item));
}

// ==================== INIT ====================
window.onload = function() {
    inicializarDatos();
    renderFeed();
    renderRanking();
    renderRecs();
    updateStats();
    
   
    const session = getCurrentSession();
    if (session) {
        currentUser = session;
        isOrganizer = currentUser.isOrganizer || false;
        loadUserData();  
        updateUserInfo();
        updateProfile();
    }

    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) closeModal(this.id);
        });
    });

    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal.show').forEach(m => closeModal(m.id));
            document.getElementById('priceFilterDropdown').classList.remove('show');
        }
    });

    document.addEventListener('click', (e) => {
        const priceFilter = document.querySelector('.price-filter-container');
        if (!priceFilter.contains(e.target)) {
            document.getElementById('priceFilterDropdown').classList.remove('show');
        }
    });
};