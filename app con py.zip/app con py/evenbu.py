from flask import Flask, render_template, request, jsonify, session
import json
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'evenbu-secret-key-2024'

DATA_FILE = 'data/evenbu_data.json'

def load_data():
    if not os.path.exists(DATA_FILE):
        os.makedirs('data', exist_ok=True)
        default = {'users': [], 'items': [], 'reservations': []}
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(default, f, indent=2)
        return default
    with open(DATA_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/register', methods=['POST'])
def api_register():
    data = load_data()
    body = request.json
    
    if any(u['email'] == body['email'] for u in data['users']):
        return jsonify({'success': False, 'message': 'Email ya registrado'}), 400
    
    new_user = {
        'id': len(data['users']) + 1,
        'name': body['name'],
        'email': body['email'],
        'password': body['password'],
        'bio': 'Nuevo en Evenbu',
        'avatar': 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200',
        'isOrganizer': False,
        'posts': 0
    }
    
    data['users'].append(new_user)
    save_data(data)
    
    return jsonify({'success': True})

@app.route('/api/login', methods=['POST'])
def api_login():
    data = load_data()
    body = request.json
    
    user = next((u for u in data['users'] if u['email'] == body['email'] and u['password'] == body['password']), None)
    
    if not user:
        return jsonify({'success': False, 'message': 'Credenciales incorrectas'}), 401
    
    session['user_id'] = user['id']
    session['user_name'] = user['name']
    
    return jsonify({'success': True, 'user': {k: v for k, v in user.items() if k != 'password'}})

@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.clear()
    return jsonify({'success': True})

if __name__ == '__main__':
    load_data()
    print("🚀 Evenbu Server en http://localhost:5000")
    app.run(debug=True, port=5000)